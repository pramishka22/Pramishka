# My Portfolio Website
Portfolio website built using HTML, CSS, Javascript and contains the following information.
* Personal info
* Education
* Technical skills
* Projects
* Contant information
